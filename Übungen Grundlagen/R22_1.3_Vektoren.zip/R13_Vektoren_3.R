codeoceanR::rt_score()

zahlenFolge <- seq(1, 20, len=15)

# A11 ----
# Wie viele Elemente befinden sich in 'zahlenFolge'? 
# Nutze den richtigen Befehl innerhalb des nachfolgenden Abschnittes.
# Es braucht kein Objekt erstellt zu werden:
# der Code zwischen t*_start und t*_end wird geprüft.
# Es genügt der Aufruf der Funktion, die ermittelt, wie viele Elemente in einem 
# Vektor sind. Als Input wähle "zahlenFolge". 
# t11_start # Lösung hiernach schreiben
length(zahlenFolge)
# t11_ende # Lösung vor dieser Zeile schreiben


# A12 ----
# Was ist das Ergebnis von zahlenFolge[30]? 
element30 <- NA
# Schreibe gerne ins Forum: Warum? 
# browseURL("https://open.hpi.de/courses/programmieren-r2022/question/941d5e04-be0b-4c28-a847-d5cea198189c")


# A13 ----
# Welcher Befehl (Funktionsaufruf) zeigt die ersten 6 Elemente von 'zahlenFolge'? 
# t13_start # Solche Zeilen immer da lassen
head(zahlenFolge)
# t13_ende


# Mache weiter in "R13_Vektoren_4.R"
