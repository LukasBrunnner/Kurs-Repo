codeoceanR::rt_score() # Anleitung in Lektion 0.4 Übungsaufgaben

# A1 ----
ergebnisBruch <- 0.075
# Es soll das Ergebnis folgender Berechnung enthalten:
0.3/4  


# Lasse deinen Code nach jeder Aufgabe bewerten.
# Score auch wenn du nicht weiterkommst:
# die Testmeldungen werden zunehmend spezifischer und hilfreicher.
# CTRL + SHIFT + S ist der einfachste Weg, um den aktuellen Punktestand zu sehen.



# A2 ----
# 'ergebnisWurzel' soll enthalten:  0.3 durch 4    mal     Wurzel aus 313600
0.3/4 * sqrt(313600)

ergebnisWurzel <- 42
# Pro Tipp: Zuweisungspfeil inkl. Leerzeichen mit Tasten 'ALT'/'OPTION' und '-'



# Um deine Lösungen zu testen, werden oft Objekte verlangt.
# Das gibt dir die Freiheit, die Lösung zu gestalten.
# Um dir Arbeit zu ersparen, wird der gewünschte Objektname oft mit einer 0 angegeben.
# Dann ist die 0 zu ersetzen (siehe nächste Aufgaben).
# Konkreter Code wird nur gelegentlich überprüft. 
# Wenn du Fragen zu deiner Lösung hast, stelle sie gerne im Forum!
# Starte deinen Thread für die beste Sichtbarkeit unter dem entsprechenden Video.


# Mache weiter in "R11_Syntax_2.R"